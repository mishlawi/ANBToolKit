Most of the chapter styles (but not all) provided by this template are taken (or adapted from) [1].

If you design a new chapter style and don't mind to have it included in the standard distribution, please let me know at
https://groups.google.com/forum/#!forum/novathesis

[1] Lars Madsen. “Various chapter styles for the memoir class.” April 11, 2012. ftp://ftp.dante.de/tex-archive/info/MemoirChapStyles/MemoirChapStyles.pdf
