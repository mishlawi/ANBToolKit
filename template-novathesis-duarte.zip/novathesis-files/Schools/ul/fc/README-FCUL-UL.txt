%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% IST-UL
%% Instituto Superior Técnico
%% Universidade de Lisboa
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Reccomendations of options to be set/changed in “template.tex”:

  school=ul/ist,
	biblatex={
		…,
		style=numeric, % or any other… depends a lot on the degree!!!
		…,
	},

